
export default async function handler(req, res){
  if(req.method!=='POST') return res.status(405).end()
  const key = process.env.STRIPE_SECRET_KEY
  const appUrl = process.env.NEXT_PUBLIC_APP_URL || 'https://www.iledont.site'
  const { amount, type } = req.body || {}
  if(!key){
    return res.json({ url: `/merci.html?type=don-demo&amount=${amount||50}` })
  }
  try{
    const Stripe = (await import('stripe')).default
    const stripe = new Stripe(key, { apiVersion: '2024-06-20' })
    const price = Math.round((amount||50)*100)
    const mode = type==='monthly' ? 'subscription' : 'payment'
    const line = type==='monthly' ? { price_data:{ currency:'eur', product_data:{ name:'Don mensuel iledont'}, unit_amount:price, recurring:{interval:'month'}}, quantity:1 } : { price_data:{ currency:'eur', product_data:{ name:'Don iledont'} , unit_amount:price}, quantity:1 }
    const session = await stripe.checkout.sessions.create({ mode, line_items:[line], success_url:`${appUrl}/merci.html?type=don`, cancel_url:`${appUrl}/#don` })
    res.json({ url: session.url })
  }catch(e){ res.status(500).json({ error: e.message }) }
}
