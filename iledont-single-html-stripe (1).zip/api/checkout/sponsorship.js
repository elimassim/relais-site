
export default async function handler(req, res){
  if(req.method!=='POST') return res.status(405).end()
  const key = process.env.STRIPE_SECRET_KEY
  const appUrl = process.env.NEXT_PUBLIC_APP_URL || 'https://www.iledont.site'
  const { childId } = req.body || {}
  if(!key){
    return res.json({ url: `/merci.html?type=demo&child=${childId||''}` })
  }
  try{
    const Stripe = (await import('stripe')).default
    const stripe = new Stripe(key, { apiVersion: '2024-06-20' })
    const session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      line_items: [{ price_data:{ currency:'eur', product_data:{ name: `Parrainage iledont - ${childId||'enfant'}`, description: 'Association Aurore - SIRET 775 684 970 03594' }, unit_amount:3500, recurring:{interval:'month'}}, quantity:1 }],
      success_url: `${appUrl}/merci.html?type=parrainage&child=${childId||''}`,
      cancel_url: `${appUrl}/#parrainer`
    })
    res.json({ url: session.url })
  }catch(e){ res.status(500).json({ error: e.message }) }
}
