iledont - SITE COMPLET EN 1 HTML + API STRIPE

Comment deployer sur Vercel (2 minutes):
1. Dezipper
2. Aller sur vercel.com > New Project > Upload ce dossier
3. Dans Vercel > Settings > Environment Variables, ajouter:
   STRIPE_SECRET_KEY=sk_live_...
   NEXT_PUBLIC_APP_URL=https://www.iledont.site
4. Deploy

Sans Stripe (mode demo):
Le site marche directement meme sans cle. Il redirige vers merci.html?type=demo

Avec Stripe (mode reel):
Apres avoir ajoute la cle et redeploye, les boutons redirigent vers Stripe Checkout puis vers merci.html avec message de remerciement.

Contact:
ASSOCIATION AURORE
31 Rue Falguière, 75015 Paris
SIRET 775 684 970 03594
iledon@iledont.site
+33 7 37 74 27 19
www.iledont.site
www.iledont.site/dons
